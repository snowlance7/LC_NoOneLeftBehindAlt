Based on this mod https://thunderstore.io/c/lethal-company/p/STAR_B/LC_NoOneLeftBehind/
Made for this modpack: https://thunderstore.io/c/lethal-company/p/Snowlance/SnowysBattleRoyale/